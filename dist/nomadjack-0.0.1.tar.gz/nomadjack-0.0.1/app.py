#!/usr/bin python3
"""
Start point to run the app.
"""
from nomadjack.cli import main

if __name__ == "__main__":
    main()
