# nomadjack

Sidecar container to run arbitrary scripts inside nomad container
