# -*- coding: utf-8 -*-
"""
Default configs for the flask application.
"""
NOMADJACK_LOCAL_DIR = '/opt/nomadjack'
NOMADJACK_APP_TITLE = 'NomadJack'
NOMADJACK_EDITOR_THEME = 'vs-dark'
