run_form_defaults = {
    "task": "",
    "script": "",
    "filepath": None,
    "fileperms": "644",
    "delete_after_exec": True,
    "override_file": False,
    "command": "/bin/sh",
    "user": None,
    "workdir": None,
    "environment": "{}",
}
